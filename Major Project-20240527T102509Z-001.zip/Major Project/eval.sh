python eval.py --path="./all.jsonl" --model="gpt-3.5-turbo"  --key='sk-proj-jeOYdfsVcTSIBcUCLQS8T3BlbkFJSNSPIHJDJSOjLqvbfo9I'  --method='raw'

